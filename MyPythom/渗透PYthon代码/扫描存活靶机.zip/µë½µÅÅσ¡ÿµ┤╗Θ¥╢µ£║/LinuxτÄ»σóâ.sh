python -m pip install --upgrade pip
pip install alive-progress